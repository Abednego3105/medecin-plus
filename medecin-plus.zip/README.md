# Médecin+ — Usine de Produits Digitaux Santé

Générez des ebooks, guides, plans alimentaires, programmes sport et bien plus en quelques secondes avec l'IA.

## Déploiement sur Vercel

1. Forkez ce repository sur GitHub
2. Connectez-le à Vercel
3. Ajoutez la variable d'environnement : `ANTHROPIC_API_KEY`
4. Déployez

## Développement local

```bash
npm install
npm run dev
```

Créez un fichier `.env.local` :
```
ANTHROPIC_API_KEY=votre_clé_ici
```

## Fonctionnalités

- 8 types de produits : Ebook, Guide Pratique, Plan Alimentaire, Programme Sport, Fiche Mémo, Quiz, Atelier, Programme Bien-être
- Format Court (10-30 pages) ou Complet (40-80+ pages)
- Draft haute qualité avec ton médical, humain, chaleureux
- Export Word (.doc) complet avec emplacements images
- Métadonnées commerciales pour Chariow, Gumroad, Selar, Payhip
- Bibliothèque de productions persistante
