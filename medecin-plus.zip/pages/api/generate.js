export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { sujet, formatId, longueur } = req.body;
  if (!sujet || !formatId || !longueur) return res.status(400).json({ error: "Parametres manquants" });

  const isComplet = longueur === "complet";
  const chapitresMap = {
    ebook: { court: 5, complet: 10 },
    guide: { court: 4, complet: 8 },
    plan_alimentaire: { court: 3, complet: 7 },
    programme_sport: { court: 4, complet: 8 },
    fiche_memo: { court: 1, complet: 2 },
    quiz: { court: 10, complet: 20 },
    atelier: { court: 4, complet: 8 },
    programme_bien_etre: { court: 5, complet: 10 },
  };
  const n = chapitresMap[formatId]?.[longueur] || 5;

  const MASTER_PROMPT = `Tu es Dr. Medecin+, un medecin bienveillant et pedagogue qui s'adresse a ses patients avec chaleur et simplicite. Tu combines la rigueur medicale avec un langage humain, naturel et accessible.

REGLES ABSOLUES :
- Jamais de jargon sans explication immediate
- Parler directement au lecteur (vous)
- Empathie avant information
- Exemples concrets du quotidien
- Terminer sur une note positive et motivante
- Eviter les formulations alarmistes
- Conseils actionnables immediatement
- Phrases courtes, paragraphes aeres
- Niveau comprehensible sans formation medicale

Reponds UNIQUEMENT en JSON valide, sans markdown, sans backticks.`;

  const structures = {
    ebook: `${n} chapitres sur : definition, causes, symptomes, diagnostic, traitements${isComplet ? ", alimentation, mode de vie, cas particuliers, soutien psychologique, vivre avec la maladie" : ", prevention"}.`,
    guide: `${n} etapes pratiques et concretes.`,
    plan_alimentaire: `${n} sections : principes nutritionnels, aliments a privilegier/eviter, menus types${isComplet ? " 7 jours" : " 3 jours"}, recettes simples.`,
    programme_sport: `${n} sections : echauffement, exercices, recuperation, progression ${isComplet ? "4 semaines" : "2 semaines"}.`,
    fiche_memo: `${n} section(s) ultra-condensee(s) : chiffres cles, signaux d'alerte, quand consulter.`,
    quiz: `${n} questions-reponses educatives du simple au precis.`,
    atelier: `${n} exercices de reflexion et d'action.`,
    programme_bien_etre: `${n} sections : rituels, habitudes saines, suivi ${isComplet ? "30 jours" : "14 jours"}.`,
  };

  const userPrompt = `Genere un produit digital sante de type "${formatId}" sur : "${sujet}"
Longueur : ${longueur}
Structure : ${structures[formatId]}

JSON attendu :
{
  "titre": "Titre accrocheur",
  "sous_titre": "Sous-titre rassurant",
  "accroche": "1-2 phrases empathiques (50 mots max)",
  "introduction": "Introduction chaleureuse (${isComplet ? 250 : 120} mots)",
  "sections": [
    {
      "numero": 1,
      "titre": "Titre section",
      "contenu": "Contenu (${isComplet ? 350 : 180} mots, ton chaleureux)",
      "points_cles": ["point 1", "point 2", "point 3"],
      "emplacement_image": "[IMAGE : description precise pour ChatGPT]"
    }
  ],
  "conclusion": "Conclusion motivante (${isComplet ? 180 : 80} mots)",
  "checklist": ["action 1", "action 2", "action 3", "action 4", "action 5"],
  "emplacements_images": ["[IMAGE COUVERTURE : description]", "[IMAGE 2 : description]"],
  "meta": {
    "prix_suggere_fcfa": 3000,
    "prix_suggere_eur": 5,
    "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"],
    "description_vente": "Description 150 mots pour page de vente",
    "titre_seo": "Titre SEO 60 caracteres max",
    "public_cible": "Description lecteur ideal"
  }
}`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4000,
        system: MASTER_PROMPT,
        messages: [{ role: "user", content: userPrompt }],
      }),
    });

    const data = await response.json();
    if (data.error) return res.status(500).json({ error: data.error.message });

    const text = data.content?.map(i => i.text || "").join("") || "";
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    return res.status(200).json(parsed);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Erreur de generation : " + err.message });
  }
}
